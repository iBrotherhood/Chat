buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // AGP 9.x provides built-in Kotlin. Pin the newer KGP runtime used by
        // that integration instead of applying org.jetbrains.kotlin.android.
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.20")
    }
}

plugins {
    id("com.android.application") version "9.3.1" apply false
}
