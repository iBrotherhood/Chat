# Cycle 03 build status

## Corrective audit after GitHub Actions logs

The failed CI runs were traced to `android-actions/setup-android@v3`, whose default package list still requested the removed Android SDK package `tools`. The workflow now uses `android-actions/setup-android@v4.0.4`, pins command-line tools build `15859902`, and installs only the required Android SDK/NDK/CMake packages.

The source audit also corrected Android-runtime issues that were not reached by the failed CI runs:

- JNI now supplies Node/libuv with argv strings in one contiguous writable buffer.
- Android passes the app-private `filesDir/freeapi` root explicitly to embedded Node.
- stale gateway port/token readiness files are removed before a fresh embedded runtime start.
- FreeLLMAPI environment variables are established before its modules are loaded.
- the mobile host binds only to `127.0.0.1` and performs safe port scanning.
- startup failures set a non-zero Node exit code without calling `process.exit()` inside the embedded host.
- the embedded bundle marker was bumped so an APK update refreshes `server.mjs` rather than retaining an older extracted bundle.
- failed chat requests no longer mutate the successful conversation history.
- Kotlin Gradle plugin was moved from 2.0.21 to 2.2.21 so AGP 8.7.3 + Gradle 8.10 are inside the documented compatibility range.

## Static verification completed

- Shell scripts: syntax checked.
- JavaScript build script: syntax checked.
- Workflow: YAML parsed and checked for the removed `tools` package / old setup-android action.
- Source contract checks cover the app-private root, contiguous JNI argv buffer, loopback binding, runtime pins and bundle version marker.

## Still requires GitHub/physical execution

This local environment does not substitute for the real GitHub Android SDK/NDK build or a physical Android phone. The corrected workflow must still assemble the APK successfully, and physical Cycle 03 acceptance still requires install, embedded startup without Termux, `/api/ping`, persistence/restart, and a real `/v1/chat/completions` request.
