# Cycle 03 build status

## Corrective audit after GitHub Actions logs

Earlier CI failures were traced to `android-actions/setup-android@v3`, whose default package list requested the removed Android SDK package `tools`. The workflow uses `android-actions/setup-android@v4.0.4`, pins command-line tools build `15859902`, and now installs the current pinned Android build stack (Build Tools 36.0.0, NDK r30, CMake 3.31.6).

The source audit also corrected Android-runtime issues that were not reached by the failed CI runs:

- JNI now supplies Node/libuv with argv strings in one contiguous writable buffer.
- Android passes the app-private `filesDir/freeapi` root explicitly to embedded Node.
- stale gateway port/token readiness files are removed before a fresh embedded runtime start.
- FreeLLMAPI environment variables are established before its modules are loaded.
- the mobile host binds only to `127.0.0.1` and performs safe port scanning.
- startup failures set a non-zero Node exit code without calling `process.exit()` inside the embedded host.
- the embedded bundle marker was bumped so an APK update refreshes `server.mjs` rather than retaining an older extracted bundle.
- failed chat requests no longer mutate the successful conversation history.
- Android build stack was migrated to AGP 9.3.1 + Gradle 9.6.0 with AGP built-in Kotlin and a pinned Kotlin Gradle runtime 2.4.20. The obsolete `org.jetbrains.kotlin.android` plugin is no longer applied.
- Java and Kotlin bytecode targets are explicitly aligned at JVM 17 via `compileOptions`; CI runs Gradle on Temurin 21 while emitting JVM 17 bytecode.
- Native toolchain is pinned to stable NDK r30 (`30.0.16248370`) and CMake `3.31.6`; Build Tools are pinned to `36.0.0`.

## Static verification completed

- Shell scripts: syntax checked.
- JavaScript build script: syntax checked.
- Workflow: YAML parsed and checked for the removed `tools` package / old setup-android action.
- Source contract checks cover the app-private root, contiguous JNI argv buffer, loopback binding, runtime pins and bundle version marker.

## Still requires GitHub/physical execution

This local environment does not substitute for the real GitHub Android SDK/NDK build or a physical Android phone. The corrected workflow must still assemble the APK successfully, and physical Cycle 03 acceptance still requires install, embedded startup without Termux, `/api/ping`, persistence/restart, and a real `/v1/chat/completions` request.

- CI guard hardened: it now detects only actual legacy Kotlin Android plugin application syntax, not comments or documentation text.

## CI run 98227686402 — guard false-positive correction

- Result before fix: CI reached Android source validation after successfully passing source ZIP integrity, FreeLLMAPI v0.12.0 bundling, Node mobile v24.21.0-0 staging, Android SDK/Build Tools/NDK/CMake provisioning, JDK 21 setup, and Gradle 9.6.0 setup.
- Fatal cause: the CI guard searched for the raw text `org.jetbrains.kotlin.android` anywhere in `build.gradle.kts` / `app/build.gradle.kts`. A comment in the root build file contained that text even though the legacy Kotlin Android plugin was not applied.
- Correction: the guard now checks only actual plugin-application syntax (`id("org.jetbrains.kotlin.android")` or `kotlin("android")`). It also rejects `android.builtInKotlin=false` in `gradle.properties`.
- Root build comment was rewritten so diagnostic text cannot impersonate configuration.
- A `gradle --no-daemon --stacktrace help` configuration preflight now runs before the full test/lint/compile/assemble stage.
- Non-fatal log noise retained as upstream warnings: npm's `node-domexception` deprecation and Android tooling's `sdkmanager` deprecation. Neither caused the failed run.

## CI run 98417933246 — Node/V8 C++20 correction

- The workflow passed source archive selection/integrity, FreeLLMAPI v0.12.0 bundling, Node mobile v24.21.0-0 staging, JDK 21, Android SDK/Build Tools 36.0.0, NDK r30, CMake 3.31.6, Gradle 9.6.0, AGP/Kotlin configuration preflight, Kotlin compilation, Java compilation and unit-test discovery.
- Fatal task: `:app:buildCMakeDebug[arm64-v8a]`.
- Root cause: the JNI compile command still contained `-std=c++17`, while Node 24/V8 headers explicitly require C++20. The subsequent `concept`, `requires`, `std::ranges` and iterator errors were cascading parser failures caused by that language-level mismatch.
- Correction: CMake is now the single source of truth for native language level with `CMAKE_CXX_STANDARD 20`, `CMAKE_CXX_STANDARD_REQUIRED ON`, extensions disabled, and `cxx_std_20` required on `myai_native`. The stale Gradle `-std=c++17` flag was removed.
- CI now rejects any archive that loses the C++20 contract or reintroduces `-std=c++17` before starting the full Gradle build.
- The AGP warning for `jniLibs.srcDirs(...)` was also removed by migrating to the `jniLibs.directories` mutable set API.
- Remaining warnings in this run (`node-domexception` deprecation from an upstream npm dependency and `sdkmanager` deprecation emitted by Android tooling) are external tool/dependency warnings and were not the build failure.
