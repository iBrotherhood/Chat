# Cycle 03 — Embedded Gateway

## Scope

Embed FreeLLMAPI directly into the Android APK, with no Termux dependency.

## Runtime

Pinned Node mobile runtime:
- repository: `fogtape/nodejs-mobile`
- release: `v24.21.0-0`
- Android full runtime artifact: `nodejs-mobile-android-24.21.0-0.zip`
- SHA-256: `e3cd29a1be03405f11dd5c857af8cd3ad13f84f1409ea648f5328f0bada5bd76`

The full runtime is used rather than the lite artifact because the FreeLLMAPI Android database adapter depends on `node:sqlite`. MyAI compiles its JNI bridge with stable Android NDK r30 (`30.0.16248370`) and C++20, which is required by the Node 24/V8 headers; the prebuilt Node mobile runtime remains independently pinned and SHA-256 verified.

## Gateway bundle

The CI build clones FreeLLMAPI at the immutable tag `v0.12.0`, creates a mobile host, and bundles the gateway with esbuild into one ESM file placed in APK assets.

Native `better-sqlite3` and `sharp` are excluded from the mobile bundle. Android uses FreeLLMAPI's `node:sqlite`; image normalization is disabled initially.

## Android boot flow

`MainActivity`
→ `GatewayRuntime`
→ `libnode.so`
→ `node server.mjs`
→ FreeLLMAPI
→ `127.0.0.1:<port>`
→ native Chat UI

The gateway writes a generated unified API key and selected local port into app-private files. The UI reads them only after `/api/ping` succeeds.

## First-install provider bootstrap

The host inserts anonymous sentinel rows for `kilo`, `llm7`, `ovh` and `aihorde`. This avoids embedding any provider credential in the APK.

The host also performs a catalog sync at startup. A catalog-sync failure does not prevent `/api/ping` readiness, because the external catalog is network-dependent.

## Security

- gateway listens on `127.0.0.1` only;
- no LAN exposure;
- provider credentials are not packaged;
- encryption key is generated in app-private storage;
- database is under app-private storage;
- Android backup is disabled;
- cleartext HTTP is enabled only because the gateway is loopback HTTP.

## Hard acceptance gate

A Cycle 03 build is **not** considered finally accepted until this exact sequence is run on a physical Android device:

1. Install APK.
2. Do not install or start Termux.
3. Launch My AI.
4. Confirm embedded Node runtime starts.
5. Confirm FreeLLMAPI reports `/api/ping` successfully.
6. Send a real `/v1/chat/completions` request.
7. Receive a real provider response.
8. Force-stop and relaunch.
9. Confirm the local database and encryption key survive.

This environment can produce and validate the source/build pipeline, but it cannot physically install the resulting APK onto a user's phone. The physical-device gate remains an explicit final verification step rather than being falsely marked as passed here.
