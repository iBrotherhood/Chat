#include <jni.h>
#include <cstring>
#include <string>
#include <vector>
#include "node.h"

extern "C" JNIEXPORT jint JNICALL
Java_com_efhc_myai_GatewayNative_startNodeWithArguments(
        JNIEnv *env,
        jclass /* clazz */,
        jobjectArray arguments) {
    const jsize argc = env->GetArrayLength(arguments);
    if (argc <= 0) return 1;

    std::vector<std::string> args;
    args.reserve(static_cast<size_t>(argc));
    size_t bufferSize = 0;

    for (jsize i = 0; i < argc; ++i) {
        auto item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        if (!item) return 2;

        const char *chars = env->GetStringUTFChars(item, nullptr);
        if (!chars) {
            env->DeleteLocalRef(item);
            return 3;
        }

        args.emplace_back(chars);
        bufferSize += args.back().size() + 1;
        env->ReleaseStringUTFChars(item, chars);
        env->DeleteLocalRef(item);
    }

    // libuv/Node expects argv strings to live in one contiguous writable block.
    // Separate std::string allocations can break process-title/argv handling in
    // embedded Node runtimes, so copy every argument into one stable buffer.
    std::vector<char> argvBuffer(bufferSize);
    std::vector<char *> argv(static_cast<size_t>(argc) + 1, nullptr);
    char *cursor = argvBuffer.data();

    for (jsize i = 0; i < argc; ++i) {
        const std::string &value = args[static_cast<size_t>(i)];
        const size_t bytes = value.size() + 1;
        std::memcpy(cursor, value.c_str(), bytes);
        argv[static_cast<size_t>(i)] = cursor;
        cursor += bytes;
    }

    return static_cast<jint>(node::Start(static_cast<int>(argc), argv.data()));
}
