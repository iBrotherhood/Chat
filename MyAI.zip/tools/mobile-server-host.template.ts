import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { Server } from 'node:http';
import type { Express } from 'express';

// Android passes the app-private gateway root as argv[2]. Environment is a
// fallback for other embedders and for diagnostics. Resolve it before loading
// any FreeLLMAPI module: several upstream modules read process.env at import
// time, so setting these values after static imports is too late.
const ROOT = path.resolve(
  process.env.MYAI_GATEWAY_ROOT?.trim()
    || process.argv[2]?.trim()
    || path.resolve(process.cwd(), 'freeapi'),
);
const DATA_DIR = path.join(ROOT, 'data');
const DB_PATH = path.join(DATA_DIR, 'freeapi.db');
const KEY_PATH = path.join(ROOT, '.encryption-key');
const PORT_FILE = path.join(ROOT, 'gateway-port');
const TOKEN_FILE = path.join(ROOT, 'gateway-token');
const DEFAULT_PORT = Number(process.env.MYAI_GATEWAY_PORT || 3017);

function ensureDirs(): void {
  fs.mkdirSync(ROOT, { recursive: true });
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function ensureEncryptionKey(): string {
  const existingEnv = process.env.ENCRYPTION_KEY?.trim();
  if (existingEnv && existingEnv !== 'your-64-char-hex-key-here') return existingEnv;

  if (fs.existsSync(KEY_PATH)) {
    const existing = fs.readFileSync(KEY_PATH, 'utf8').trim();
    if (/^[0-9a-fA-F]{64}$/.test(existing)) return existing;
    throw new Error(`Invalid persisted encryption key at ${KEY_PATH}`);
  }

  const key = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(KEY_PATH, key, { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(KEY_PATH, 0o600); } catch {}
  return key;
}

function prepareEnvironment(): void {
  ensureDirs();
  process.env.NODE_ENV = 'production';
  process.env.MYAI_GATEWAY_ROOT = ROOT;
  process.env.HOST = '127.0.0.1';
  process.env.PORT = String(DEFAULT_PORT);
  process.env.FREEAPI_DB_PATH = DB_PATH;
  process.env.ENCRYPTION_KEY = ensureEncryptionKey();
  process.env.IMAGE_NORMALIZE = 'off';
  process.env.FREEAPI_DB_DIR_HARDENING = '1';
  process.env.FREEAPI_ENV_PATH = path.join(ROOT, 'mobile-no-env');
  process.chdir(ROOT);
}

function tryListen(app: Express, host: string, port: number): Promise<Server | null> {
  return new Promise((resolve, reject) => {
    const server = app.listen(port, host);
    server.once('listening', () => resolve(server));
    server.once('error', (err: NodeJS.ErrnoException) => {
      if (err.code === 'EADDRINUSE') resolve(null);
      else reject(err);
    });
  });
}

async function listenWithScan(
  app: Express,
  start: number,
  attempts = 50,
): Promise<{ server: Server; port: number }> {
  for (let port = start; port < start + attempts; ++port) {
    const server = await tryListen(app, '127.0.0.1', port);
    if (server) return { server, port };
  }
  throw new Error(`No free loopback port found in ${start}-${start + attempts - 1}`);
}

async function startServer(): Promise<void> {
  prepareEnvironment();

  // Load dotenv only after FREEAPI_ENV_PATH is pinned to the app-private root,
  // then load the rest of FreeLLMAPI. Literal dynamic imports are still bundled
  // by esbuild, but their module initializers now see the Android environment.
  await import('../server/src/env.js');

  const [
    { createApp },
    dbModule,
    cryptoModule,
    { loadConfig },
    { restoreProxySettings },
    { loadCacheFromDb },
    { cleanupExpiredCooldowns },
    catalogModule,
    { installLogRedaction },
    { startHealthChecker },
    { startCooldownProbe },
    { startCustomModelSync },
    { NodeScheduler },
  ] = await Promise.all([
    import('../server/src/app.js'),
    import('../server/src/db/index.js'),
    import('../server/src/lib/crypto.js'),
    import('../server/src/lib/config.js'),
    import('../server/src/lib/proxy.js'),
    import('../server/src/services/cache.js'),
    import('../server/src/services/ratelimit.js'),
    import('../server/src/services/catalog-sync.js'),
    import('../server/src/lib/log-redaction.js'),
    import('../server/src/services/health.js'),
    import('../server/src/services/cooldown-probe.js'),
    import('../server/src/services/custom-model-sync.js'),
    import('../server/src/lib/scheduler.js'),
  ]);

  const { initDb, getDb, getUnifiedApiKey } = dbModule;
  const { encrypt } = cryptoModule;
  const { syncCatalog, startCatalogSync } = catalogModule;

  const ensureKeylessProvider = (platform: string): void => {
    const db = getDb();
    const existing = db.prepare('SELECT id FROM api_keys WHERE platform = ? LIMIT 1').get(platform) as { id: number } | undefined;
    if (existing) return;
    const { encrypted, iv, authTag } = encrypt('no-key');
    db.prepare(`
      INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled)
      VALUES (?, 'MyAI built-in anonymous route', ?, ?, ?, 'unknown', 1)
    `).run(platform, encrypted, iv, authTag);
  };

  installLogRedaction();
  initDb(DB_PATH);
  for (const platform of ['kilo', 'llm7', 'ovh', 'aihorde']) ensureKeylessProvider(platform);
  loadCacheFromDb();
  const expired = cleanupExpiredCooldowns();
  if (expired > 0) console.log(`[MyAI] cleared ${expired} expired cooldowns`);
  restoreProxySettings();

  const config = {
    ...loadConfig(),
    host: '127.0.0.1',
    port: DEFAULT_PORT,
    dbPath: DB_PATH,
    clientDist: null,
    serveStaticAssets: false,
    nodeEnv: 'production',
  };

  const app = createApp(config);
  const { server, port } = await listenWithScan(app, DEFAULT_PORT);
  const scheduler = new NodeScheduler();
  startHealthChecker(scheduler);
  startCatalogSync(scheduler);
  startCooldownProbe(scheduler);
  startCustomModelSync(getDb(), scheduler);

  fs.writeFileSync(PORT_FILE, String(port), { encoding: 'utf8', mode: 0o600 });
  fs.writeFileSync(TOKEN_FILE, getUnifiedApiKey(), { encoding: 'utf8', mode: 0o600 });
  try {
    fs.chmodSync(PORT_FILE, 0o600);
    fs.chmodSync(TOKEN_FILE, 0o600);
  } catch {}
  console.log(`[MyAI] FreeLLMAPI ready on 127.0.0.1:${port}`);

  // Remote catalog refresh is best-effort; an offline catalog must not prevent
  // the local gateway from becoming available to the Android client.
  void syncCatalog(true)
    .then((result: any) => console.log(`[MyAI] catalog sync: ${result?.status ?? 'completed'}`))
    .catch((err: any) => console.warn(`[MyAI] catalog sync failed; gateway remains available: ${err?.message ?? err}`));

  const shutdown = (): void => {
    try { server.close(); } catch {}
    try { getDb().close?.(); } catch {}
  };
  process.once('SIGTERM', shutdown);
  process.once('SIGINT', shutdown);
}

startServer().catch((err) => {
  console.error(`[MyAI] gateway startup failed: ${err?.stack ?? err}`);
  // Do not call process.exit() inside an embedded runtime. A non-zero exitCode
  // lets Node unwind naturally so the JNI host can report the failure to Android.
  process.exitCode = 1;
});
