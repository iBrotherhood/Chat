# MyAI — Cycle 03

Self-contained Android APK architecture with FreeLLMAPI embedded inside the application.

The APK build does not require Termux. GitHub Actions downloads a pinned Node mobile runtime, verifies its SHA-256, bundles the pinned FreeLLMAPI release, and packages the native runtime plus gateway bundle into the APK.

### What is inside

- Native Android Chat UI.
- Embedded Node runtime (`libnode.so`).
- FreeLLMAPI server bundle.
- Android `node:sqlite` database path.
- App-private encrypted provider configuration.
- Loopback-only local gateway.
- `/api/ping` readiness check.
- `/v1/chat/completions` client path.

### Build

The intended build path is GitHub Actions. The workflow runs:

`build-freeapi.sh` → `prepare-node-runtime.sh` → `gradle assembleDebug`

The runtime asset is deliberately downloaded during the build rather than committed to the repository.

### Physical-device acceptance

The final Cycle 03 criterion requires a real Android phone to install the APK, start the embedded runtime without Termux, answer `/api/ping`, and complete one real `/v1/chat/completions` request. That hardware step must be performed outside this build environment.

### Physical device gate

See `PHYSICAL_DEVICE_ACCEPTANCE.md` for the exact final test. Cycle 03 is not physically accepted until the APK passes that procedure on a real Android phone without Termux.
