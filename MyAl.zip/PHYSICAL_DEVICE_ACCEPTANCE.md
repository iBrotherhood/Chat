# Cycle 03 — physical Android acceptance

This is the final gate. It must be performed on a real Android phone.

## Preconditions

Do not install or start Termux. Install only the MyAI APK.

## Test

1. Install the debug APK from the GitHub Actions artifact.
2. Open **My AI**.
3. The status must move from `Gateway: запускается` to `Gateway: готов • loopback`.
4. The system message must state that FreeLLMAPI is running inside the APK and `/api/ping` answers.
5. Leave the model as `auto`.
6. Send a simple prompt such as `Ответь одним словом: OK`.
7. A real assistant response must appear. This is the `/v1/chat/completions` path through the embedded FreeLLMAPI gateway.
8. Force-stop the application from Android settings.
9. Launch it again.
10. The gateway must start again and reach the ready state.

## Failure capture

When the gate fails, record:
- Android version;
- phone CPU architecture;
- APK build/run number;
- the exact status/message shown by MyAI;
- `adb logcat | grep -E 'MyAI|NODEJS-MOBILE|FreeLLMAPI'` output when ADB is available.

## Notes

Cycle 03 uses FreeLLMAPI `v0.12.0` and a pinned Node mobile runtime. The first build configures keyless providers so no provider API key is packaged into the APK. Actual provider availability remains dependent on the external provider service and its current free-tier conditions.
