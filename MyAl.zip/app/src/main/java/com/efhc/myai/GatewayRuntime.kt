package com.efhc.myai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

class GatewayRuntime(context: Context) {
    private val context = context.applicationContext
    data class Connection(val baseUrl: String, val apiKey: String)

    private val started = AtomicBoolean(false)
    private val exitCode = AtomicReference<Int?>(null)
    private val thread = AtomicReference<Thread?>(null)
    private val http = OkHttpClient.Builder().build()

    private val rootDir: File by lazy { File(context.filesDir, "freeapi") }
    private val projectDir: File by lazy { File(rootDir, "node-project") }
    private val dataDir: File by lazy { File(rootDir, "data") }
    private val portFile: File by lazy { File(rootDir, "gateway-port") }
    private val tokenFile: File by lazy { File(rootDir, "gateway-token") }
    private val bundleVersionFile: File by lazy { File(rootDir, "bundle-version") }

    suspend fun start(): Result<Connection> = withContext(Dispatchers.IO) {
        try {
            prepareProjectFiles()
            rootDir.mkdirs()
            dataDir.mkdirs()
            if (!started.compareAndSet(false, true)) {
                return@withContext awaitReady()
            }
            exitCode.set(null)

            val t = Thread {
                try {
                    val args = arrayOf("node", File(projectDir, "server.mjs").absolutePath)
                    val code = GatewayNative.startNodeWithArguments(args)
                    exitCode.set(code)
                } catch (t: Throwable) {
                    System.err.println("[MyAI] Node runtime failed: ${t.message}")
                    exitCode.set(-1)
                } finally {
                    started.set(false)
                }
            }
            t.name = "MyAI-FreeLLMAPI"
            t.isDaemon = true
            thread.set(t)
            t.start()

            awaitReady()
        } catch (t: Throwable) {
            Result.failure(t)
        }
    }

    private fun prepareProjectFiles() {
        rootDir.mkdirs()
        val marker = File(projectDir, "server.mjs")
        val assetVersion = readAssetText("node-project/version.txt").trim()
        val installedVersion = bundleVersionFile.takeIf { it.exists() }?.readText()?.trim().orEmpty()
        if (marker.exists() && marker.length() > 0L && assetVersion.isNotEmpty() && installedVersion == assetVersion) {
            return
        }

        projectDir.deleteRecursively()
        copyAssetTree("node-project", projectDir)
        if (assetVersion.isNotEmpty()) {
            bundleVersionFile.writeText(assetVersion)
        }
    }

    private fun readAssetText(path: String): String {
        return context.assets.open(path).use { it.bufferedReader(Charsets.UTF_8).readText() }
    }

    private fun copyAssetTree(assetPath: String, target: File) {
        target.mkdirs()
        val children = context.assets.list(assetPath).orEmpty()
        for (child in children) {
            val source = "$assetPath/$child"
            val destination = File(target, child)
            val nested = context.assets.list(source).orEmpty()
            if (nested.isNotEmpty()) {
                copyAssetTree(source, destination)
            } else {
                context.assets.open(source).use { input -> copyStream(input, destination) }
            }
        }
    }

    private fun copyStream(input: InputStream, target: File) {
        target.parentFile?.mkdirs()
        FileOutputStream(target).use { output ->
            input.copyTo(output, DEFAULT_BUFFER)
        }
    }

    private suspend fun awaitReady(timeoutMs: Long = 90_000L): Result<Connection> {
        val startedAt = System.currentTimeMillis()
        var lastError: Throwable? = null
        while (System.currentTimeMillis() - startedAt < timeoutMs) {
            val code = exitCode.get()
            if (code != null && code != 0) {
                return Result.failure(IllegalStateException("FreeLLMAPI process exited with code $code"))
            }

            val port = portFile.takeIf { it.exists() }
                ?.readText()
                ?.trim()
                ?.toIntOrNull()
                ?: DEFAULT_PORT
            val base = "http://127.0.0.1:$port/v1"
            try {
                val request = Request.Builder().url("http://127.0.0.1:$port/api/ping").get().build()
                http.newCall(request).execute().use { response ->
                    if (response.isSuccessful) {
                        val token = tokenFile.takeIf { it.exists() }?.readText()?.trim().orEmpty()
                        if (token.isNotEmpty()) return Result.success(Connection(base, token))
                    }
                }
            } catch (t: Throwable) {
                lastError = t
            }
            delay(250L)
        }
        return Result.failure(lastError ?: IllegalStateException("FreeLLMAPI readiness timeout"))
    }

    companion object {
        private const val DEFAULT_PORT = 3017
        private const val DEFAULT_BUFFER = 16 * 1024

        @Volatile
        private var processInstance: GatewayRuntime? = null

        fun get(context: Context): GatewayRuntime {
            return processInstance ?: synchronized(this) {
                processInstance ?: GatewayRuntime(context).also { processInstance = it }
            }
        }
    }
}
