package com.efhc.myai;

final class GatewayNative {
    static {
        System.loadLibrary("node");
        System.loadLibrary("myai_native");
    }

    private GatewayNative() {}

    static native int startNodeWithArguments(String[] arguments);
}
