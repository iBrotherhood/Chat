package com.efhc.myai

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var chatView: TextView
    private lateinit var input: EditText
    private lateinit var sendButton: Button
    private lateinit var modelSpinner: Spinner
    private lateinit var statusView: TextView
    private lateinit var scroll: ScrollView

    private val history = JSONArray()
    private lateinit var runtime: GatewayRuntime
    private var gateway: AiGateway? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chatView = findViewById(R.id.chatView)
        input = findViewById(R.id.input)
        sendButton = findViewById(R.id.sendButton)
        modelSpinner = findViewById(R.id.modelSpinner)
        statusView = findViewById(R.id.statusView)
        scroll = findViewById(R.id.scroll)

        modelSpinner.adapter = ArrayAdapter(
            this,
            android.R.layout.simple_spinner_dropdown_item,
            listOf("auto", "auto:smart", "auto:fast")
        )

        sendButton.isEnabled = false
        sendButton.setOnClickListener { sendMessage() }

        runtime = GatewayRuntime.get(applicationContext)
        append("Система", "Запускаю встроенный FreeLLMAPI без Termux…")
        startGateway()
    }

    private fun startGateway() {
        statusView.text = "Gateway: запускается"
        lifecycleScope.launch {
            val result = runtime.start()
            result.onSuccess { connection ->
                gateway = AiGateway(connection.baseUrl, connection.apiKey)
                statusView.text = "Gateway: готов • loopback"
                append("Система", "FreeLLMAPI запущен внутри APK. /api/ping отвечает.")
                sendButton.isEnabled = true
                input.requestFocus()
            }.onFailure { error ->
                statusView.text = "Gateway: ошибка"
                append("Система", "Не удалось запустить FreeLLMAPI: ${error.message}")
            }
        }
    }

    private fun sendMessage() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        val client = gateway ?: return

        append("Вы", text)
        input.text.clear()
        sendButton.isEnabled = false

        lifecycleScope.launch {
            val result = client.chat(
                model = modelSpinner.selectedItem.toString(),
                history = history,
                userText = text
            )
            append("AI", result)
            sendButton.isEnabled = true
        }
    }

    private fun append(author: String, text: String) {
        chatView.append("\n\n$author:\n$text")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }
}

class AiGateway(
    private val baseUrl: String,
    private val apiKey: String
) {
    private val client = okhttp3.OkHttpClient.Builder().build()

    suspend fun chat(model: String, history: JSONArray, userText: String): String =
        kotlinx.coroutines.withContext(Dispatchers.IO) {
            try {
                history.put(JSONObject().apply {
                    put("role", "user")
                    put("content", userText)
                })

                val body = JSONObject().apply {
                    put("model", model)
                    put("messages", history)
                    put("stream", false)
                }

                val request = okhttp3.Request.Builder()
                    .url("${baseUrl.trimEnd('/')}/chat/completions")
                    .post(body.toString().toRequestBody("application/json".toMediaType()))
                    .addHeader("Authorization", "Bearer $apiKey")
                    .build()

                client.newCall(request).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) {
                        return@withContext "Ошибка FreeLLMAPI ${response.code}: $raw"
                    }

                    val json = JSONObject(raw)
                    val answer = json
                        .getJSONArray("choices")
                        .getJSONObject(0)
                        .getJSONObject("message")
                        .optString("content", "Пустой ответ")

                    history.put(JSONObject().apply {
                        put("role", "assistant")
                        put("content", answer)
                    })
                    answer
                }
            } catch (e: Exception) {
                "Ошибка соединения с FreeLLMAPI: ${e.message}"
            }
        }
}

private fun String.toRequestBody(mediaType: okhttp3.MediaType) =
    okhttp3.RequestBody.create(mediaType, this)

private fun String.toMediaType() =
    okhttp3.MediaType.get(this)
