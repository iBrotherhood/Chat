#include <jni.h>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include "node.h"

extern "C" JNIEXPORT jint JNICALL
Java_com_efhc_myai_GatewayNative_startNodeWithArguments(
        JNIEnv *env,
        jclass /* clazz */,
        jobjectArray arguments) {
    const jsize argc = env->GetArrayLength(arguments);
    if (argc <= 0) return 1;

    std::vector<std::string> strings;
    strings.reserve(static_cast<size_t>(argc));
    std::vector<char*> argv;
    argv.reserve(static_cast<size_t>(argc));

    for (jsize i = 0; i < argc; i++) {
        jstring item = static_cast<jstring>(env->GetObjectArrayElement(arguments, i));
        if (!item) return 2;
        const char* chars = env->GetStringUTFChars(item, nullptr);
        if (!chars) return 3;
        strings.emplace_back(chars);
        env->ReleaseStringUTFChars(item, chars);
        env->DeleteLocalRef(item);
    }

    for (auto& s : strings) argv.push_back(s.data());
    return static_cast<jint>(node::Start(static_cast<int>(argc), argv.data()));
}
