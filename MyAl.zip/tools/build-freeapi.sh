#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FREEAPI_ROOT="$ROOT/.build/freeapi"
REF="v0.12.0"
rm -rf "$FREEAPI_ROOT"
mkdir -p "$FREEAPI_ROOT"
git clone --depth 1 --branch "$REF" https://github.com/tashfeenahmed/freellmapi.git "$FREEAPI_ROOT"
mkdir -p "$FREEAPI_ROOT/mobile"
cp "$ROOT/tools/mobile-server-host.template.ts" "$FREEAPI_ROOT/mobile/server-host.ts"
cd "$FREEAPI_ROOT"
npm ci --omit=optional --no-audit --no-fund
cd "$ROOT"
node tools/build-mobile-server.mjs
