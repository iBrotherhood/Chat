import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import type { Server } from 'node:http';
import '../server/src/env.js';
import { createApp } from '../server/src/app.js';
import { initDb, getDb, getUnifiedApiKey } from '../server/src/db/index.js';
import { encrypt } from '../server/src/lib/crypto.js';
import { loadConfig } from '../server/src/lib/config.js';
import { restoreProxySettings } from '../server/src/lib/proxy.js';
import { loadCacheFromDb } from '../server/src/services/cache.js';
import { cleanupExpiredCooldowns } from '../server/src/services/ratelimit.js';
import { syncCatalog } from '../server/src/services/catalog-sync.js';
import { installLogRedaction } from '../server/src/lib/log-redaction.js';
import { startHealthChecker } from '../server/src/services/health.js';
import { startCatalogSync } from '../server/src/services/catalog-sync.js';
import { startCooldownProbe } from '../server/src/services/cooldown-probe.js';
import { startCustomModelSync } from '../server/src/services/custom-model-sync.js';
import { NodeScheduler } from '../server/src/lib/scheduler.js';

const ROOT = process.env.MYAI_GATEWAY_ROOT || path.resolve(process.cwd(), 'freeapi');
const DATA_DIR = path.join(ROOT, 'data');
const DB_PATH = path.join(DATA_DIR, 'freeapi.db');
const KEY_PATH = path.join(ROOT, '.encryption-key');
const PORT_FILE = path.join(ROOT, 'gateway-port');
const TOKEN_FILE = path.join(ROOT, 'gateway-token');
const DEFAULT_PORT = Number(process.env.MYAI_GATEWAY_PORT || 3017);

function ensureDirs() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.mkdirSync(ROOT, { recursive: true });
}

function ensureEncryptionKey(): string {
  if (process.env.ENCRYPTION_KEY && process.env.ENCRYPTION_KEY !== 'your-64-char-hex-key-here') {
    return process.env.ENCRYPTION_KEY;
  }
  if (fs.existsSync(KEY_PATH)) {
    return fs.readFileSync(KEY_PATH, 'utf8').trim();
  }
  const key = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(KEY_PATH, key, { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(KEY_PATH, 0o600); } catch {}
  return key;
}

function ensureKeylessProvider(platform: string) {
  const db = getDb();
  const existing = db.prepare('SELECT id FROM api_keys WHERE platform = ? LIMIT 1').get(platform) as { id: number } | undefined;
  if (existing) return;
  const { encrypted, iv, authTag } = encrypt('no-key');
  db.prepare(`
    INSERT INTO api_keys (platform, label, encrypted_key, iv, auth_tag, status, enabled)
    VALUES (?, 'MyAI built-in anonymous route', ?, ?, ?, 'unknown', 1)
  `).run(platform, encrypted, iv, authTag);
}

function listenWithScan(app: ReturnType<typeof createApp>, start: number): Promise<{ server: Server; port: number }> {
  return new Promise((resolve, reject) => {
    const attempt = (port: number) => {
      const server = app.listen(port, '127.0.0.1');
      server.once('listening', () => resolve({ server, port }));
      server.once('error', (err: NodeJS.ErrnoException) => {
        if (err.code === 'EADDRINUSE' && port < start + 50) {
          server.close(() => attempt(port + 1));
        } else {
          reject(err);
        }
      });
    };
    attempt(start);
  });
}

async function startServer() {
  ensureDirs();
  process.env.NODE_ENV = 'production';
  process.env.MYAI_GATEWAY_ROOT = ROOT;
  process.env.HOST = '127.0.0.1';
  process.env.PORT = String(DEFAULT_PORT);
  process.env.FREEAPI_DB_PATH = DB_PATH;
  process.env.ENCRYPTION_KEY = ensureEncryptionKey();
  process.env.IMAGE_NORMALIZE = 'off';
  process.env.FREEAPI_DB_DIR_HARDENING = '1';
  process.env.FREEAPI_ENV_PATH = path.join(ROOT, 'mobile-no-env');

  installLogRedaction();
  initDb(DB_PATH);
  for (const platform of ['kilo', 'llm7', 'ovh', 'aihorde']) ensureKeylessProvider(platform);
  loadCacheFromDb();
  const expired = cleanupExpiredCooldowns();
  if (expired > 0) console.log(`[MyAI] cleared ${expired} expired cooldowns`);
  restoreProxySettings();

  const config = {
    ...loadConfig(),
    host: '127.0.0.1',
    port: DEFAULT_PORT,
    dbPath: DB_PATH,
    clientDist: null,
    serveStaticAssets: false,
    nodeEnv: 'production',
  };
  const app = createApp(config);
  const { server, port } = await listenWithScan(app, DEFAULT_PORT);
  const scheduler = new NodeScheduler();
  startHealthChecker(scheduler);
  startCatalogSync(scheduler);
  startCooldownProbe(scheduler);
  startCustomModelSync(getDb(), scheduler);

  fs.writeFileSync(PORT_FILE, String(port), { encoding: 'utf8', mode: 0o600 });
  fs.writeFileSync(TOKEN_FILE, getUnifiedApiKey(), { encoding: 'utf8', mode: 0o600 });
  try { fs.chmodSync(PORT_FILE, 0o600); fs.chmodSync(TOKEN_FILE, 0o600); } catch {}
  console.log(`[MyAI] FreeLLMAPI ready on 127.0.0.1:${port}`);

  // The catalog is remote and therefore not guaranteed to be reachable at boot.
  // Try it once before declaring the initial embedded installation ready.
  try {
    const result = await syncCatalog(true);
    console.log(`[MyAI] catalog sync: ${result.status ?? 'completed'}`);
  } catch (err: any) {
    console.warn(`[MyAI] catalog sync failed; gateway remains available: ${err?.message ?? err}`);
  }

  process.on('SIGTERM', () => shutdown(server));
  process.on('SIGINT', () => shutdown(server));
}

function shutdown(server: Server) {
  try { server.close(); } catch {}
  try { getDb().close?.(); } catch {}
}

startServer().catch((err) => {
  console.error(`[MyAI] gateway startup failed: ${err?.stack ?? err}`);
  // Keep the native host alive long enough for Android to observe the failed
  // process instead of immediately killing the VM through process.exit().
  setTimeout(() => {}, 60_000);
});
