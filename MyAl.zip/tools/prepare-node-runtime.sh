#!/usr/bin/env bash
set -euo pipefail

VERSION="v24.21.0-0"
URL="https://github.com/fogtape/nodejs-mobile/releases/download/${VERSION}/nodejs-mobile-android-24.21.0-0.zip"
SHA256="e3cd29a1be03405f11dd5c857af8cd3ad13f84f1409ea648f5328f0bada5bd76"
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT

mkdir -p "$ROOT/app/src/main/jniLibs" "$ROOT/app/src/main/libnode"
ZIP="$TMP/nodejs-mobile.zip"

echo "Downloading pinned Node mobile runtime ${VERSION}..."
curl -fsSL --retry 3 --retry-all-errors "$URL" -o "$ZIP"
echo "${SHA256}  ${ZIP}" | sha256sum -c -
unzip -q "$ZIP" -d "$TMP/runtime"

for abi in arm64-v8a armeabi-v7a x86_64; do
  so="$(find "$TMP/runtime" -type f -path "*/bin/${abi}/libnode.so" -print -quit)"
  test -n "$so"
  mkdir -p "$ROOT/app/src/main/jniLibs/$abi"
  cp "$so" "$ROOT/app/src/main/jniLibs/$abi/libnode.so"
done

header="$(find "$TMP/runtime" -type f -path '*/include/node/node.h' -print -quit)"
test -n "$header"
include_root="$(dirname "$(dirname "$header")")"
rm -rf "$ROOT/app/src/main/libnode/include"
cp -R "$include_root" "$ROOT/app/src/main/libnode/include"

echo "Node mobile runtime staged."
