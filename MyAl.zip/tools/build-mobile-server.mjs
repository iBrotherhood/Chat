import path from 'node:path';
import { createRequire } from 'node:module';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const freeapiRoot = path.resolve(root, '.build/freeapi');
const requireFromFreeLLMAPI = createRequire(path.join(freeapiRoot, 'desktop/package.json'));
const { build } = requireFromFreeLLMAPI('esbuild');

await build({
  entryPoints: [path.join(freeapiRoot, 'mobile/server-host.ts')],
  bundle: true,
  platform: 'node',
  format: 'esm',
  target: 'node22',
  outfile: path.join(root, 'app/src/main/assets/node-project/server.mjs'),
  external: ['better-sqlite3', 'sharp'],
  logLevel: 'info',
  banner: {
    js: "import { createRequire as __createRequire } from 'node:module'; const require = __createRequire(import.meta.url);",
  },
});
